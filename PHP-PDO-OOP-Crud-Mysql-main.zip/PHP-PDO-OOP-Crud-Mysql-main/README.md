# crud-php-pdo-oop
In this package I have built a sample php crud with pdo extension in oop with bootstrap and MySQL database... 

Database Creation
---------------------------------------------
CREATE TABLE IF NOT EXISTS `tbl_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `contact_no` bigint(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;
#   P H P - P D O - C r u d - M y s q l  
 