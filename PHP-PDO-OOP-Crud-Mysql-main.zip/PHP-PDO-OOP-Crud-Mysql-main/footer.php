<div class="container">
    <div class="alert alert-success">
        <div class="text-center">
            <strong>SUHAIMEE YAKOH</strong> !
        </div>
    </div>
</div>
<script src="bootstrap/js/bootstrap.min.js"></script>
</body>

</html>